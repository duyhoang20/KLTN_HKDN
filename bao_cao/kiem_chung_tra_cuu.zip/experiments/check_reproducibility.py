import hashlib,json,sys
from pathlib import Path
from run_evaluation import install
ROOT=Path(__file__).resolve().parents[1]
D,S=install(ROOT/'deliverables/search.py');S.xay_chi_muc(D)
trace=json.loads((ROOT/'experiments/baseline_trace.json').read_text(encoding='utf-8'))
indices=list(range(0,1500,15))+[845,1010,1018,1056,1085]
results=[]
for i in indices:
 q=trace[i]['q'];r=S.search(q,D)
 results.append([q,[[x[0].id,x[1],x[2]] for x in r]])
print(hashlib.sha256(json.dumps(results,ensure_ascii=False).encode('utf-8')).hexdigest())
