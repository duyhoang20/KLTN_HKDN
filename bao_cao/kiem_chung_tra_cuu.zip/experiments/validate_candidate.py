"""Supplementary validation on real records: disjoint target IDs and accents.
The primary gate still uses unchanged danh_gia.py and its original 500 queries.
"""
import collections,json,random,sys,time,unicodedata
from pathlib import Path
from run_evaluation import install,evaluator
ROOT=Path(__file__).resolve().parents[1]
D,base=install(ROOT/'upload/search.py');D=sorted(D,key=lambda d:d.id)
_,new=install(ROOT/'deliverables/search.py');E=evaluator()
base.xay_chi_muc(D);new.xay_chi_muc(D)
by={d.id:d for d in D};all_records={}

def measure(items,mod):
 rows=[]
 for idx,(d,q) in enumerate(items,1):
  result=mod.search(q,D);ids=[x[0].id for x in result]
  rank=ids.index(d.id)+1 if d.id in ids else None
  rows.append({'target':d.id,'q':q,'rank':rank,'n':len(ids)})
 return rows

def summary(rows):
 n=len(rows)
 return {'n':n,'top1':sum(x['rank']==1 for x in rows), 'top5':sum(x['rank'] is not None and x['rank']<=5 for x in rows), 'mrr':sum(1/x['rank'] if x['rank'] else 0 for x in rows)/n,'missing':sum(x['rank'] is None for x in rows),'avg_results':sum(x['n'] for x in rows)/n}

for j,(ma,kieu) in enumerate([('A','day_du'),('B','mot_doan')]):
 used={d.id for d,q in E.tao_bo_de(D,500,kieu,E.SEED+j)}
 # Exclude ALL A/B/C target IDs used in selecting the coefficient.
 all_used=set()
 for offset,k in enumerate(['day_du','mot_doan','chung_chung']):
  all_used.update(d.id for d,q in E.tao_bo_de(D,500,k,E.SEED+offset))
 unused=[d for d in D if d.id not in all_used]
 held=E.tao_bo_de(unused,500,kieu,20260924+j)
 assert not ({d.id for d,q in held}&all_used)
 # Preserve the original accented spelling as normalized by the current
 # search code; do not invent a new query intent. A/B cut rules stay the same.
 rng=random.Random(20260924+j)
 accent=[]
 for d,_ in held:
  syl=base.norm_dau(d.title).split()
  if len(syl)<5:continue
  if ma=='A':q=' '.join(syl[:25])
  else:
   n=max(4,int(len(syl)*0.6));start=rng.randint(0,len(syl)-n)
   q=' '.join(syl[start:start+n])
  accent.append((d,q))
 for group,items in [('heldout_'+ma,held),('accent_'+ma,accent)]:
  before=measure(items,base);after=measure(items,new)
  worse=[{'before':a,'after':b} for a,b in zip(before,after) if (b['rank'] or 10**9)>(a['rank'] or 10**9)]
  all_records[group]={'before':summary(before),'after':summary(after),'worse_count':len(worse),'rows_before':before,'rows_after':after,'worse':worse}
  print(group,summary(before),summary(after),'worse',len(worse),flush=True)
  Path(ROOT/'experiments/validation.json').write_text(json.dumps(all_records,ensure_ascii=False,indent=2), encoding="utf-8")

# Rank movements in the primary A/B evaluation, including lower ranks.
b=json.loads((ROOT/'experiments/baseline_trace.json').read_text(encoding='utf-8'));a=json.loads((ROOT/'experiments/final_trace.json').read_text(encoding='utf-8'))
for j,kieu in enumerate(['day_du','mot_doan']):
 items=E.tao_bo_de(D,500,kieu,E.SEED+j);better=worse=0
 for (d,q),r0,r1 in zip(items,b[j*500:(j+1)*500],a[j*500:(j+1)*500]):
  assert q==r0['q']==r1['q']
  p0=r0['ids'].index(d.id)+1 if d.id in r0['ids'] else 10**9
  p1=r1['ids'].index(d.id)+1 if d.id in r1['ids'] else 10**9
  better+=p1<p0;worse+=p1>p0
 all_records['primary_'+str(j)]={'better':better,'worse':worse,'unchanged':500-better-worse}
 print('primary',kieu,all_records['primary_'+str(j)],flush=True)
Path(ROOT/'experiments/validation.json').write_text(json.dumps(all_records,ensure_ascii=False,indent=2), encoding="utf-8")
