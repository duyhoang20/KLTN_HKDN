"""Run unchanged danh_gia.py using real exported records, without PostgreSQL.
Only the read-only DB access layer is adapted. Search and evaluator are loaded
from the specified source files and execute their actual implementations.
"""
import argparse, importlib.util, json, sys, types, time
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

def install(search_path, data_path=ROOT/'upload/du_lieu_danh_gia.json'):
    payload=json.loads(Path(data_path).read_text(encoding='utf-8-sig'))
    records=[types.SimpleNamespace(**d) for d in payload['documents']]
    class Field:
        def __init__(self,name): self.name=name
        def __eq__(self,value): return (self.name,value)
    class GuidanceDocument:
        id=Field('id'); status=Field('status')
    class Query:
        def __init__(self,records): self.records=list(records)
        def filter(self,predicate):
            key,value=predicate
            self.records=[d for d in self.records if getattr(d,key)==value]
            return self
        def order_by(self,field):
            self.records.sort(key=lambda d:getattr(d,field.name)); return self
        def all(self): return self.records
    class Session:
        def query(self,model):
            assert model is GuidanceDocument
            return Query(records)
        def close(self): pass
    app=types.ModuleType('app'); app.__path__=[]
    models=types.ModuleType('app.models'); models.GuidanceDocument=GuidanceDocument
    database=types.ModuleType('app.database'); database.SessionLocal=Session
    app.models=models; app.database=database
    sys.modules.update({'app':app,'app.models':models,'app.database':database})
    spec=importlib.util.spec_from_file_location('app.search',search_path)
    search=importlib.util.module_from_spec(spec); sys.modules['app.search']=search
    spec.loader.exec_module(search); app.search=search
    return records,search

def evaluator():
    path=ROOT/'deliverables/danh_gia.py'
    spec=importlib.util.spec_from_file_location('danh_gia',path)
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
    return mod

def main():
    p=argparse.ArgumentParser();p.add_argument('--search',required=True);p.add_argument('--report',required=True);p.add_argument('--n',type=int,default=500);p.add_argument('--trace')
    a=p.parse_args();docs,s=install(Path(a.search).resolve());e=evaluator()
    trace=[]; real_search=s.search
    def tracked(q,docs,*args,**kwargs):
        t=time.perf_counter(); result=real_search(q,docs,*args,**kwargs)
        trace.append({'q':q,'ids':[x[0].id for x in result], 'scores':[x[1] for x in result], 'ms':(time.perf_counter()-t)*1000})
        return result
    s.search=tracked
    sys.argv=['danh_gia.py',str(a.n),'--luu',a.report]
    start=time.perf_counter(); ret=e.main()
    if a.trace:Path(a.trace).write_text(json.dumps(trace,ensure_ascii=False),encoding='utf-8')
    print('WALL_SECONDS',round(time.perf_counter()-start,3))
    return ret
if __name__=='__main__':raise SystemExit(main())
